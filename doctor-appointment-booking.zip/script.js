/**
 * DR. PRADHUMAN JAIN - CLINIC WEB APP LOGIC
 * Seamless Integration between Patient-Side & Admin-Side via LocalStorage
 */

// Initial Mock Data (runs only on first load to make the demo immediately engaging)
const INITIAL_APPOINTMENTS = [
  {
    id: "APT-101",
    name: "Aarav Sharma",
    mobile: "9876543210",
    age: "5",
    symptoms: "Dry cough, mild fever since last night, not eating properly.",
    date: getOffsetDateString(0), // Today
    time: "10:30 AM",
    status: "Confirmed",
    history: "First visit for flu symptoms. Prescribed paracetamol 250mg drops.",
    timestamp: Date.now() - 3600000 * 4
  },
  {
    id: "APT-102",
    name: "Ananya Mehta",
    mobile: "9414012345",
    age: "2",
    symptoms: "Routine 24-month vaccination (MMR booster) & weight check.",
    date: getOffsetDateString(0), // Today
    time: "11:00 AM",
    status: "Pending",
    history: "Perfect developmental milestones. Weight is 12.4 kg.",
    timestamp: Date.now() - 3600000 * 2
  },
  {
    id: "APT-103",
    name: "Reyansh Trivedi",
    mobile: "8107567890",
    age: "8",
    symptoms: "Sharp stomach ache after eating school lunch, vomiting once.",
    date: getOffsetDateString(1), // Tomorrow
    time: "05:00 PM",
    status: "Pending",
    history: "History of lactose intolerance. Advised diet monitoring.",
    timestamp: Date.now() - 3600000 * 1
  },
  {
    id: "APT-104",
    name: "Kabir Joshi",
    mobile: "7014298765",
    age: "0.8", // 9 months
    symptoms: "Severe skin rash on cheeks and neck, persistent crying.",
    date: getOffsetDateString(0), // Today
    time: "06:30 PM",
    status: "Pending",
    history: "Atopic dermatitis suspect. Hypoallergenic moisturizers prescribed.",
    timestamp: Date.now() - 300000
  },
  {
    id: "APT-105",
    name: "Pari Rathore",
    mobile: "9929212345",
    age: "4",
    symptoms: "Completed treatment for ear infection, coming for final follow-up.",
    date: getOffsetDateString(-2), // 2 days ago
    time: "05:30 PM",
    status: "Completed",
    history: "Ear infection resolved. Tympanic membrane looks healthy.",
    timestamp: Date.now() - 3600000 * 48
  }
];

const INITIAL_NOTIFICATIONS = [
  { id: 1, text: "New booking request from Kabir Joshi (9m) for Severe skin rash.", time: "5 mins ago", unread: true },
  { id: 2, text: "Appointment with Aarav Sharma confirmed for today.", time: "4 hours ago", unread: false },
  { id: 3, text: "System Boot: Dr. Pradhuman Jain clinic demo loaded successfully.", time: "1 day ago", unread: false }
];

// Utilities
function getOffsetDateString(offsetDays) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// LocalStorage Handlers
function getStoredAppointments() {
  const data = localStorage.getItem("dr_jain_appointments");
  if (!data) {
    localStorage.setItem("dr_jain_appointments", JSON.stringify(INITIAL_APPOINTMENTS));
    return INITIAL_APPOINTMENTS;
  }
  return JSON.parse(data);
}

function saveAppointments(appointments) {
  localStorage.setItem("dr_jain_appointments", JSON.stringify(appointments));
}

function getStoredNotifications() {
  const data = localStorage.getItem("dr_jain_notifications");
  if (!data) {
    localStorage.setItem("dr_jain_notifications", JSON.stringify(INITIAL_NOTIFICATIONS));
    return INITIAL_NOTIFICATIONS;
  }
  return JSON.parse(data);
}

function saveNotifications(notifications) {
  localStorage.setItem("dr_jain_notifications", JSON.stringify(notifications));
}

// Check Realtime Clinic Status (Dr's Clinic is active based on real current time in Banswara)
function updateClinicLiveStatus() {
  const statusEl = document.getElementById("clinic-status-badge");
  const heroStatusEl = document.getElementById("hero-clinic-status");
  if (!statusEl && !heroStatusEl) return;

  const now = new Date();
  const day = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
  const hour = now.getHours();
  const minute = now.getMinutes();
  const decimalTime = hour + minute / 60;

  let isOpen = false;
  let text = "Clinic Closed - Booking App Open";

  if (day === 0) { // Sunday
    if (decimalTime >= 10.0 && decimalTime <= 13.0) {
      isOpen = true;
      text = "Open Now (Sunday Emergencies Only)";
    }
  } else { // Monday to Saturday
    const morningStart = 9.0;
    const morningEnd = 13.0;
    const eveningStart = 16.5; // 4:30 PM
    const eveningEnd = 20.5;   // 8:30 PM

    if ((decimalTime >= morningStart && decimalTime <= morningEnd) || 
        (decimalTime >= eveningStart && decimalTime <= eveningEnd)) {
      isOpen = true;
      text = "Clinic Open Now";
    } else if (decimalTime > morningEnd && decimalTime < eveningStart) {
      text = "Clinic Closed - Evening Session Starts at 4:30 PM";
    } else {
      text = "Clinic Closed - Reopens Tomorrow at 9:00 AM";
    }
  }

  const badgeHtml = isOpen 
    ? `<span class="pulse-green mr-2"></span> <span class="text-emerald-700 font-semibold">${text}</span>`
    : `<span class="pulse-red mr-2"></span> <span class="text-rose-700 font-semibold">${text}</span>`;

  if (statusEl) {
    statusEl.innerHTML = badgeHtml;
  }
  if (heroStatusEl) {
    heroStatusEl.innerHTML = isOpen 
      ? `<span class="pulse-green mr-1.5"></span> Open Now`
      : `<span class="pulse-red mr-1.5"></span> Booking Open`;
  }
}

// Run immediately & set interval
document.addEventListener("DOMContentLoaded", () => {
  updateClinicLiveStatus();
  setInterval(updateClinicLiveStatus, 30000); // refresh every 30s
  
  // Create beautiful icon instances
  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }

  // --- PATIENT-SIDE LOGIC (index.html) ---
  if (document.getElementById("appointment-form")) {
    initPatientPage();
  }

  // --- ADMIN-SIDE LOGIC (admin.html) ---
  if (document.getElementById("admin-dashboard")) {
    initAdminPage();
  }
});


/* ==============================================
   PATIENT PAGE CONTROLLER
   ============================================== */
function initPatientPage() {
  const dateInput = document.getElementById("apt-date");
  const timeSlotContainer = document.getElementById("time-slots-grid");
  const selectedTimeInput = document.getElementById("selected-time");
  const appointmentForm = document.getElementById("appointment-form");
  const successModal = document.getElementById("success-modal");
  const closeModalBtn = document.getElementById("close-modal-btn");
  const proceedWhatsAppBtn = document.getElementById("proceed-whatsapp-btn");

  // Format Date picker: restrict to today -> +30 days
  const todayStr = getOffsetDateString(0);
  const maxDateStr = getOffsetDateString(30);
  dateInput.min = todayStr;
  dateInput.max = maxDateStr;
  dateInput.value = todayStr;

  // Render Time Slots based on Date
  function renderTimeSlots(selectedDate) {
    timeSlotContainer.innerHTML = "";
    selectedTimeInput.value = ""; // Clear selected slot

    // Check weekday
    const d = new Date(selectedDate);
    const isSunday = d.getDay() === 0;

    let slots = [];
    if (isSunday) {
      slots = ["10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM"];
    } else {
      slots = [
        "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM",
        "04:30 PM", "05:00 PM", "05:30 PM", "06:00 PM", "06:30 PM", "07:00 PM", "07:30 PM", "08:00 PM"
      ];
    }

    // Get currently booked slots for this date to prevent double booking
    const currentApts = getStoredAppointments();
    const busySlots = currentApts
      .filter(apt => apt.date === selectedDate && apt.status !== "Rejected")
      .map(apt => apt.time);

    slots.forEach(slot => {
      const slotBtn = document.createElement("button");
      slotBtn.type = "button";
      slotBtn.className = "time-slot-btn text-slate-700 transition";
      slotBtn.textContent = slot;

      if (busySlots.includes(slot)) {
        slotBtn.classList.add("disabled");
        slotBtn.disabled = true;
        slotBtn.title = "This slot is already booked";
      } else {
        slotBtn.addEventListener("click", () => {
          // Deselect previous
          document.querySelectorAll(".time-slot-btn").forEach(btn => btn.classList.remove("selected"));
          slotBtn.classList.add("selected");
          selectedTimeInput.value = slot;
        });
      }
      timeSlotContainer.appendChild(slotBtn);
    });
  }

  // Initial load
  renderTimeSlots(todayStr);

  // Re-render when date changes
  dateInput.addEventListener("change", (e) => {
    renderTimeSlots(e.target.value);
  });

  // Sticky Book Button scroll effect
  const stickyBookBtn = document.getElementById("sticky-book-btn");
  if (stickyBookBtn) {
    window.addEventListener("scroll", () => {
      const heroSection = document.getElementById("hero-section");
      if (heroSection) {
        const heroBottom = heroSection.getBoundingClientRect().bottom;
        if (heroBottom < 0) {
          stickyBookBtn.classList.remove("opacity-0", "pointer-events-none");
          stickyBookBtn.classList.add("opacity-100");
        } else {
          stickyBookBtn.classList.add("opacity-0", "pointer-events-none");
          stickyBookBtn.classList.remove("opacity-100");
        }
      }
    });
  }

  // Animated statistics counter counters (micro effect)
  const statsCounters = document.querySelectorAll(".stat-counter");
  if (statsCounters.length > 0) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const target = parseInt(entry.target.getAttribute("data-target"));
          let count = 0;
          const duration = 1500;
          const increment = target / (duration / 16);
          const update = () => {
            count += increment;
            if (count >= target) {
              entry.target.textContent = target + (entry.target.getAttribute("data-suffix") || "");
            } else {
              entry.target.textContent = Math.floor(count) + (entry.target.getAttribute("data-suffix") || "");
              requestAnimationFrame(update);
            }
          };
          update();
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    statsCounters.forEach(counter => observer.observe(counter));
  }

  // Smooth floating labels click
  const inputs = document.querySelectorAll(".glass-input");
  inputs.forEach(input => {
    input.placeholder = " "; // triggers pattern matching for floating labels
  });

  // Current appointment details stored state globally for redirect
  let pendingAptDetails = null;

  // Form submission validation
  appointmentForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("patient-name").value.trim();
    const mobile = document.getElementById("patient-mobile").value.trim();
    const age = document.getElementById("patient-age").value.trim();
    const symptoms = document.getElementById("patient-symptoms").value.trim();
    const date = dateInput.value;
    const time = selectedTimeInput.value;

    // Custom alerts using nice in-app warnings instead of blocky window.alert
    if (!name || !mobile || !age || !symptoms) {
      showToast("Please fill in all the patient details", "error");
      return;
    }

    if (!/^\d{10}$/.test(mobile)) {
      showToast("Please enter a valid 10-digit mobile number", "error");
      return;
    }

    if (isNaN(parseFloat(age)) || parseFloat(age) < 0 || parseFloat(age) > 18) {
      showToast("Child age must be between 0 and 18 years", "error");
      return;
    }

    if (!time) {
      showToast("Please select an available booking time slot", "error");
      return;
    }

    // New Booking Object
    const newApt = {
      id: "APT-" + Date.now().toString().slice(-4),
      name,
      mobile,
      age,
      symptoms,
      date,
      time,
      status: "Pending",
      history: "New pediatric case. No prior records.",
      timestamp: Date.now()
    };

    // Save Booking
    const appointments = getStoredAppointments();
    appointments.unshift(newApt);
    saveAppointments(appointments);

    // Save Notification for Demo
    const notifications = getStoredNotifications();
    notifications.unshift({
      id: Date.now(),
      text: `New online slot request: ${name} (${age} yrs) for "${symptoms.substring(0, 30)}..."`,
      time: "Just now",
      unread: true
    });
    saveNotifications(notifications);

    // Store details for WhatsApp Redirect action
    pendingAptDetails = newApt;

    // Success Modal Animation triggers
    successModal.classList.remove("hidden");
    document.body.style.overflow = "hidden"; // locking scroll
    
    // Clear inputs
    appointmentForm.reset();
    renderTimeSlots(dateInput.value);
  });

  // Close popup
  closeModalBtn.addEventListener("click", () => {
    successModal.classList.add("hidden");
    document.body.style.overflow = "";
  });

  // Generate WhatsApp details and fire redirect
  proceedWhatsAppBtn.addEventListener("click", () => {
    if (!pendingAptDetails) return;

    // Text Template
    const border = "================================";
    const text = `*New Appointment Booking*
${border}
*Patient Name:* ${pendingAptDetails.name}
*Mobile Number:* ${pendingAptDetails.mobile}
*Child Age:* ${pendingAptDetails.age} Years
*Symptoms:* ${pendingAptDetails.symptoms}
*Selected Date:* ${pendingAptDetails.date}
*Selected Time:* ${pendingAptDetails.time}

*Doctor:* Dr Pradhuman Jain
*Clinic Location:* Banswara, Rajasthan
${border}`;

    const encodedText = encodeURIComponent(text);
    const whatsappUrl = `https://wa.me/919414000000?text=${encodedText}`;
    
    // Close modal
    successModal.classList.add("hidden");
    document.body.style.overflow = "";

    // Tab redirects safely without being caught by iframe blockers inside a target open callback
    window.open(whatsappUrl, "_blank");
  });
}


/* ==============================================
   DOCTOR ADMIN PAGE CONTROLLER
   ============================================== */
function initAdminPage() {
  const sidebar = document.getElementById("admin-sidebar");
  const toggleBtn = document.getElementById("sidebar-toggle");
  const closeSidebarBtn = document.getElementById("close-sidebar-btn");
  const searchInput = document.getElementById("search-input");
  const rescheduleModal = document.getElementById("reschedule-modal");
  const cancelRescheduleBtn = document.getElementById("cancel-reschedule-btn");
  const rescheduleForm = document.getElementById("reschedule-form");

  let currentRescheduleId = null;

  // Hamburger Toggle logic
  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.add("open");
    });
  }
  if (closeSidebarBtn) {
    closeSidebarBtn.addEventListener("click", () => {
      sidebar.classList.remove("open");
    });
  }

  // Tab Navigation Setup
  const tabs = document.querySelectorAll("[data-tab]");
  const sections = document.querySelectorAll(".admin-section");

  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      const targetSec = tab.getAttribute("data-tab");
      
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");

      sections.forEach(s => {
        if (s.id === targetSec) {
          s.classList.remove("hidden");
        } else {
          s.classList.add("hidden");
        }
      });

      // Collapse sidebar on mobile once clicked
      if (window.innerWidth < 1024) {
        sidebar.classList.remove("open");
      }
    });
  });

  // Search Logic
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      const query = e.target.value.toLowerCase();
      renderAppointmentsTable(query);
      renderPatientsSection(query);
    });
  }

  // Setup Reschedule fields limit
  const reschDate = document.getElementById("reschedule-date");
  if (reschDate) {
    reschDate.min = getOffsetDateString(0);
    reschDate.max = getOffsetDateString(30);
  }

  // Form submission rescheduling
  if (rescheduleForm) {
    rescheduleForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const date = document.getElementById("reschedule-date").value;
      const time = document.getElementById("reschedule-time-slot").value;

      if (!date || !time) {
        showToast("Please choose valid date and time slots", "error");
        return;
      }

      const apts = getStoredAppointments();
      const targetIdx = apts.findIndex(a => a.id === currentRescheduleId);
      if (targetIdx !== -1) {
        apts[targetIdx].date = date;
        apts[targetIdx].time = time;
        apts[targetIdx].status = "Confirmed"; // auto approve when rescheduled by doctor
        saveAppointments(apts);

        // Notify
        const notes = getStoredNotifications();
        notes.unshift({
          id: Date.now(),
          text: `Rescheduled: ${apts[targetIdx].name} updated to ${date} at ${time}.`,
          time: "Just now",
          unread: true
        });
        saveNotifications(notes);

        showToast("Appointment rescheduled and confirmed successfully!");
        closeRescheduleModal();
        refreshAdminData();
      }
    });
  }

  if (cancelRescheduleBtn) {
    cancelRescheduleBtn.addEventListener("click", closeRescheduleModal);
  }

  // Prime trigger for main loading cycle
  refreshAdminData();
}

function closeRescheduleModal() {
  const modal = document.getElementById("reschedule-modal");
  if (modal) {
    modal.classList.add("hidden");
    document.body.style.overflow = "";
  }
}

// Master Admin Update Engine
function refreshAdminData() {
  updateDashboardMetrics();
  renderAppointmentsTable();
  renderPatientsSection();
  renderNotificationsList();
}

// Dashboard statistics
function updateDashboardMetrics() {
  const apts = getStoredAppointments();
  const todayStr = getOffsetDateString(0);

  const todayCount = apts.filter(a => a.date === todayStr && a.status !== "Rejected").length;
  const pendingCount = apts.filter(a => a.status === "Pending").length;
  const confirmedCount = apts.filter(a => a.status === "Confirmed").length;
  const totalCount = new Set(apts.map(a => a.mobile)).size;

  document.getElementById("stat-today").textContent = todayCount;
  document.getElementById("stat-total-pat").textContent = totalCount;
  document.getElementById("stat-pending").textContent = pendingCount;
  document.getElementById("stat-confirmed").textContent = confirmedCount;

  // update small warning badge in side navigation dynamically
  const pendingBadge = document.getElementById("menu-pending-badge");
  if (pendingBadge) {
    if (pendingCount > 0) {
      pendingBadge.textContent = pendingCount;
      pendingBadge.classList.remove("hidden");
    } else {
      pendingBadge.classList.add("hidden");
    }
  }
}

// Table list rendering
function renderAppointmentsTable(filterQuery = "") {
  const listBody = document.getElementById("appointments-tbody");
  if (!listBody) return;

  const apts = getStoredAppointments();
  listBody.innerHTML = "";

  const filtered = apts.filter(apt => {
    const term = filterQuery.toLowerCase();
    return apt.name.toLowerCase().includes(term) || 
           apt.mobile.includes(term) || 
           apt.symptoms.toLowerCase().includes(term);
  });

  if (filtered.length === 0) {
    listBody.innerHTML = `
      <tr>
        <td colspan="7" class="py-12 text-center text-slate-400 font-medium">
          <div class="flex flex-col items-center justify-center gap-2">
            <svg class="h-8 w-8 text-slate-500 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586A1 1 0 0113 3.414L17.586 8a1 1 0 01.414.707V19a2 2 0 01-2 2z"></path></svg>
            No active or matched appointments found
          </div>
        </td>
      </tr>
    `;
    return;
  }

  filtered.forEach(apt => {
    const tr = document.createElement("tr");
    tr.className = "border-b border-slate-800 hover:bg-slate-900/40 transition";

    let badgeClass = "badge-pending";
    if (apt.status === "Confirmed") badgeClass = "badge-confirmed";
    if (apt.status === "Rejected") badgeClass = "badge-rejected";
    if (apt.status === "Completed") badgeClass = "badge-completed";

    tr.innerHTML = `
      <td class="py-4 px-4 font-semibold text-slate-200">
        <div>${apt.name} <span class="text-slate-500 font-normal text-xs ml-1">(${apt.age}y/o)</span></div>
        <div class="text-[11px] text-slate-400 font-mono tracking-wider">${apt.id}</div>
      </td>
      <td class="py-4 px-4 font-mono text-slate-300">${apt.mobile}</td>
      <td class="py-4 px-4 text-slate-300 max-w-xs truncate" title="${apt.symptoms}">${apt.symptoms}</td>
      <td class="py-4 px-4 text-slate-300">${formatHumanDate(apt.date)}</td>
      <td class="py-4 px-4 text-slate-300 font-medium">${apt.time}</td>
      <td class="py-4 px-4">
        <span class="badge-status ${badgeClass}">${apt.status}</span>
      </td>
      <td class="py-4 px-4 text-right">
        <div class="flex items-center justify-end gap-1.5">
          ${apt.status === "Pending" ? `
            <button onclick="approveApt('${apt.id}')" class="px-2.5 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500 hover:text-white text-emerald-400 text-xs font-semibold transition" title="Approve Booking">Accept</button>
            <button onclick="rejectApt('${apt.id}')" class="px-2.5 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500 hover:text-white text-rose-400 text-xs font-semibold transition" title="Decline Patient">Reject</button>
          ` : ""}
          ${apt.status !== "Completed" && apt.status !== "Rejected" ? `
            <button onclick="triggerReschedule('${apt.id}')" class="px-2.5 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500 hover:text-white text-cyan-400 text-xs font-semibold transition" title="Reschedule Session">Reschedule</button>
            <button onclick="completeApt('${apt.id}')" class="px-2.5 py-1.5 rounded-lg bg-indigo-500/15 hover:bg-indigo-500 hover:text-white text-indigo-400 text-xs font-semibold transition" title="Complete Medical Visit">Done</button>
          ` : ""}
        </div>
      </td>
    `;
    listBody.appendChild(tr);
  });
}

// Patient Records visualizer
function renderPatientsSection(filterQuery = "") {
  const container = document.getElementById("patients-grid");
  if (!container) return;

  const apts = getStoredAppointments();
  container.innerHTML = "";

  // Unique patients grouping by mobile number
  const uniquePatients = {};
  apts.forEach(apt => {
    if (!uniquePatients[apt.mobile]) {
      uniquePatients[apt.mobile] = {
        name: apt.name,
        mobile: apt.mobile,
        age: apt.age,
        visits: []
      };
    }
    // append clinical notes
    uniquePatients[apt.mobile].visits.push({
      date: apt.date,
      time: apt.time,
      symptoms: apt.symptoms,
      status: apt.status,
      history: apt.history || "No notes entered."
    });
  });

  const query = filterQuery.toLowerCase();
  const records = Object.values(uniquePatients).filter(pat => {
    return pat.name.toLowerCase().includes(query) || pat.mobile.includes(query);
  });

  if (records.length === 0) {
    container.innerHTML = `
      <div class="col-span-full py-12 text-center text-slate-400">
        No patient profiles match your active search terms.
      </div>
    `;
    return;
  }

  records.forEach(pat => {
    const card = document.createElement("div");
    card.className = "rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col justify-between";
    
    let visitsHtml = "";
    pat.visits.forEach(v => {
      let iconColor = "text-amber-500";
      if (v.status === "Confirmed") iconColor = "text-emerald-500";
      if (v.status === "Completed") iconColor = "text-indigo-400";

      visitsHtml += `
        <div class="mt-3.5 border-t border-slate-800/60 pt-3">
          <div class="flex items-center justify-between text-xs">
            <span class="font-semibold text-slate-300">${formatHumanDate(v.date)} at ${v.time}</span>
            <span class="font-bold uppercase tracking-wider ${iconColor}">${v.status}</span>
          </div>
          <p class="text-[13px] text-slate-400 mt-1"><span class="text-slate-500">Reason:</span> ${v.symptoms}</p>
          <div class="mt-1.5 p-2 bg-slate-950/80 rounded-lg">
            <div class="text-[10px] text-sky-400 font-bold tracking-wider mb-0.5">DOCTOR'S CLINICAL NOTE:</div>
            <p class="text-xs text-slate-300 italic">"${v.history}"</p>
          </div>
        </div>
      `;
    });

    card.innerHTML = `
      <div>
        <div class="flex items-center justify-between">
          <div>
            <h3 class="font-bold text-slate-100 text-lg flex items-center gap-1.5">
              ${pat.name} 
              <span class="text-xs bg-slate-800 px-2 py-0.5 rounded-full text-slate-400">${pat.age} yrs</span>
            </h3>
            <p class="text-xs text-slate-500 font-mono mt-0.5">${pat.mobile}</p>
          </div>
          <button onclick="triggerAddLog('${pat.mobile}')" class="text-xs bg-sky-500/10 text-sky-400 px-2.5 py-1.5 rounded-lg border border-sky-500/20 hover:bg-sky-500 hover:text-white transition font-medium">Add Note</button>
        </div>
        <div class="mt-4">
          <h4 class="text-xs font-bold text-slate-500 tracking-wider">CONSULTATION HISTORIES</h4>
          ${visitsHtml}
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

// Notifications sidebar panel
function renderNotificationsList() {
  const panel = document.getElementById("notifications-list");
  if (!panel) return;

  const notes = getStoredNotifications();
  panel.innerHTML = "";

  if (notes.length === 0) {
    panel.innerHTML = `<div class="p-4 text-center text-slate-500 text-xs">No notifications.</div>`;
    return;
  }

  notes.slice(0, 8).forEach(n => {
    const item = document.createElement("div");
    item.className = `p-4 border-b border-slate-800/60 flex flex-col gap-1 transition-all ${n.unread ? "bg-slate-900/30 border-l-4 border-l-sky-500" : ""}`;

    item.innerHTML = `
      <div class="flex items-start justify-between">
        <p class="text-xs font-medium text-slate-200">${n.text}</p>
        ${n.unread ? `<span onclick="markNotificationRead(${n.id})" class="text-[10px] text-sky-400 font-bold hover:underline cursor-pointer flex-shrink-0">Read</span>` : ""}
      </div>
      <div class="text-[10px] text-slate-500 font-semibold mt-1">${n.time}</div>
    `;
    panel.appendChild(item);
  });
}

function markNotificationRead(id) {
  const notes = getStoredNotifications();
  const idx = notes.findIndex(n => n.id === id);
  if (idx !== -1) {
    notes[idx].unread = false;
    saveNotifications(notes);
    renderNotificationsList();
  }
}

// Helper formatting human readable date
function formatHumanDate(dateStr) {
  const dateObj = new Date(dateStr);
  if (isNaN(dateObj.getTime())) return dateStr;
  return dateObj.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

// Interactive Toast Alerts
function showToast(text, type = "success") {
  const toast = document.createElement("div");
  toast.className = `fixed bottom-5 right-5 px-5 py-3.5 rounded-xl text-white font-medium shadow-2xl z-50 transition transform translate-y-2 opacity-0 flex items-center gap-2 ${
    type === "success" 
      ? "bg-slate-900 border border-emerald-500/30" 
      : "bg-rose-950 border border-rose-500/40"
  }`;

  const icon = type === "success" 
    ? `<span class="text-emerald-400">✓</span>` 
    : `<span class="text-rose-400">⚠</span>`;

  toast.innerHTML = `${icon} <span class="text-sm">${text}</span>`;
  document.body.appendChild(toast);

  // Animation triggers
  setTimeout(() => {
    toast.classList.remove("translate-y-2", "opacity-0");
    toast.classList.add("translate-y-0", "opacity-100");
  }, 50);

  // Auto clear
  setTimeout(() => {
    toast.classList.remove("translate-y-0", "opacity-100");
    toast.classList.add("translate-y-2", "opacity-0");
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}


/* ==============================================
   EXPOSED ACTION TRIGGERS (Global Context)
   ============================================== */

window.approveApt = function(id) {
  const apts = getStoredAppointments();
  const idx = apts.findIndex(a => a.id === id);
  if (idx !== -1) {
    apts[idx].status = "Confirmed";
    saveAppointments(apts);

    const notes = getStoredNotifications();
    notes.unshift({
      id: Date.now(),
      text: `Approved: ${apts[idx].name} booked for ${apts[idx].date} at ${apts[idx].time}.`,
      time: "Just now",
      unread: true
    });
    saveNotifications(notes);

    showToast(`Appointment of ${apts[idx].name} has been Accepted!`);
    refreshAdminData();
  }
};

window.rejectApt = function(id) {
  const apts = getStoredAppointments();
  const idx = apts.findIndex(a => a.id === id);
  if (idx !== -1) {
    const patientName = apts[idx].name;
    apts[idx].status = "Rejected";
    saveAppointments(apts);

    const notes = getStoredNotifications();
    notes.unshift({
      id: Date.now(),
      text: `Cancelled: Booking for ${patientName} declined.`,
      time: "Just now",
      unread: true
    });
    saveNotifications(notes);

    showToast(`Appointment of ${patientName} has been Declined.`, "error");
    refreshAdminData();
  }
};

window.completeApt = function(id) {
  const apts = getStoredAppointments();
  const idx = apts.findIndex(a => a.id === id);
  if (idx !== -1) {
    apts[idx].status = "Completed";
    saveAppointments(apts);

    showToast(`Medical consultation for ${apts[idx].name} marked as Completed!`);
    refreshAdminData();
  }
};

window.triggerReschedule = function(id) {
  const apts = getStoredAppointments();
  const apt = apts.find(a => a.id === id);
  if (apt) {
    currentRescheduleId = id;
    const modal = document.getElementById("reschedule-modal");
    if (modal) {
      modal.classList.remove("hidden");
      document.body.style.overflow = "hidden"; // locking scroll
    }
  }
};

window.triggerAddLog = function(mobile) {
  // Add customized pediatrician history notes inside a clinical record
  const note = prompt("Enter specialized clinical notes / vaccine logs for this visit:");
  if (note === null) return;
  const noteStr = note.trim();

  const apts = getStoredAppointments();
  // find latest appointment with this mobile and patch the clinical notes history
  const patientAppointments = apts.filter(a => a.mobile === mobile);
  if (patientAppointments.length > 0) {
    // sort by timestamp descending
    patientAppointments.sort((a,b) => b.timestamp - a.timestamp);
    const newestApt = apts.find(a => a.id === patientAppointments[0].id);
    if (newestApt) {
      newestApt.history = noteStr ? noteStr : "No prior records.";
      saveAppointments(apts);
      showToast("Clinical notes updated successfully!");
      refreshAdminData();
    }
  }
};
